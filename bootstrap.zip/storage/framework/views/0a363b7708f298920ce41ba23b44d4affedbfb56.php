<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>You are previewing sample projects. All projects below are small samples of how to compose each section of your dissertation.</span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">Project samples</span></p>
    </div>
    <div class="main-body">
      <div class="text--group">
        <h1>Project Samples</h1>
        <p>All of the project samples below are small fragments of what should be expected for each project, *Note this is not the full amount of content which should be expected, as your dissertation project will be on a much larger scale.</p>
        <ul class="sample--list">
          <?php foreach($blog as $blogs): ?>
            <li><a href="/student/dashboard/sample-projects/<?php echo e($blogs->slug); ?>"><span><?php echo e($blogs->blog_title); ?></span> <img src="/images/icons/arrow-right-circle.svg"></a> </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>