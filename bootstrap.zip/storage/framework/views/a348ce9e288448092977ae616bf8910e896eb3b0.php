<?php $__env->startSection('title', 'Project Bazaar, Login'); ?>
<?php $__env->startSection('content'); ?>
<main class="split--group">
  <section class="section--form">
    <div class="form--group">
      <h2>Let's get you started.</h2>
        <?php echo Form::open(); ?>

          <?php echo Form::label('staff_email', 'Your Email address'); ?>

          <?php echo Form::email('staff_email', null, ['placeholder' => 'e.g. firstname.lastname@go.edgehill.ac.uk']); ?>


          <?php echo Form::label('staff_password', 'Your password:'); ?>

          <?php echo Form::password('staff_password', null); ?>

          <div class="submit-block">
            <?php echo Form::submit('Login', null, ['class' => 'btn']); ?>

          </div>
         <?php echo Form::close(); ?>

      </form>
    </div>
<?php echo $__env->make('templates.stafffooterlinks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </section>
  <section class="section--block">
    <div class="hero">
      <?php echo $__env->make('templates.bazaar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>