<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>Create a new blog post</span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">Create your blog post</span></p>
    </div>
    <div class="main-body">
      <div class="text--group">
        <h1>Create a new blog post</h1>
        <h2>Blog Details</h2>
        <?php echo Form::open(['url' => '/staff/dashboard/blog', 'autocomplete' => 'off']); ?>

          <?php echo Form::label('blog_title', 'Your Title *'); ?>

          <?php echo Form::text('blog_title', null, ['placeholder' => 'e.g. What is a dissertation project?']); ?>

          <?php echo Form::label('type', 'Which pathway best suits this project?'); ?>

          <select name="type" id="type">
            <?php foreach($types as $type): ?>
              <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
            <?php endforeach; ?>
          </select>
          <?php echo Form::label('blog_content', 'Blog Content'); ?>

          <?php echo Form::textarea('blog_content', null, ['placeholder' => "This is where the main body of your blog will go"]); ?>


          <?php echo Form::submit('Submit Blog', null, ['class' => 'btn']); ?>

         <?php echo Form::close(); ?>

      </div>
    </div>



  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.staffdashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>