<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <?php foreach($project as $pro): ?>
    <?php endforeach; ?>
    <div class="toolbar toolbar--top">
      <?php echo e($project->project_name); ?>

    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span><a href="/student/dashboard/">All projects</a> / <?php echo e($project->project_name); ?></span></p>
    </div>
    <div class="main-body">
      <div class="text--group">
        <h1><?php echo e($project->project_name); ?></h1>
        <p><?php echo e($project->project_description); ?></p>
      </div>
    </div>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>