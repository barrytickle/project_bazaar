<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>Commenst for project <?php echo e($project->project_name); ?></span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">Project Comments</span></p>
    </div>
    <div class="main-body">
      <div class="text--group">
        <h1 style="margin-bottom:30px;"><?php echo e($project->project_name); ?></h1>
        <?php if($project->is_authorized): ?>
          <?php if($project->staff[0]->staff_name == Auth::user()->staff->staff_name): ?>
            <a class="btn btn-approve" href="/staff/dashboard/projects/<?php echo e($project->id); ?>/approve" >Unapprove Project</a>
          <?php else: ?>
            <?php echo e($project->staff[0]->staff_name); ?> must unapprove
          <?php endif; ?>

        <?php else: ?>
          <a class="btn btn-approve" href="/staff/dashboard/projects/<?php echo e($project->id); ?>/approve">Approve Project</a>
        <?php endif; ?>
        <p><?php echo e($project->project_description); ?></p>

        <div class="comments">
          <?php foreach($comments as $comment): ?>

          <article class="comment">
            <a class="comment-img" href="#non">
              <img src="/images/logo/crest-colour.svg" alt="" width="50" height="50">
            </a>
            <div class="comment-body">
              <div class="text">
                <p><?php echo e($comment->pivot->project_comment); ?></p>
              </div>
              <p class="attribution">
                by
                <?php if($comment->role[0]->name == 'staff'): ?>
                  <?php echo e($comment->staff->staff_name); ?> - Tutor
                <?php else: ?>
                  <?php echo e($comment->student->student_id); ?> - Student
                <?php endif; ?>
              </p>
            </div>
          </article>
        <?php endforeach; ?>
        </div>


        <h2>Make a comment</h2>
        <?php echo Form::open(['method' => 'POST','url' => 'staff/dashboard/projects/comment/'. $project->id, 'class' => 'comment--form']); ?>

          <?php echo Form::label('project_comment', 'Add Comment'); ?>

          <?php echo Form::textarea('project_comment', null,  ['placeholder' => 'Add to the thread of the comments']); ?>

          <?php echo Form::submit('Add Comment', null, ['class' => 'btn']); ?>

         <?php echo Form::close(); ?>

      </div>
    </div>



  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.staffdashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>