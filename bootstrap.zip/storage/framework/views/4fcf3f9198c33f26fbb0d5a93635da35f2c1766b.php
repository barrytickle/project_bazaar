<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>Create your own project</span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">Create your own project</span></p>
    </div>
    <div class="main-body">
      <div class="text--group">
        <h1>Create your own project</h1>
        <p>Now it's your time to shine, proposing your own project scope couldn't be any easier. Simply fill out the form below, this will then need to be proposed by your tutor before being visible to all users throughout the system.</p>

        <h2>Project Details</h2>
        <?php echo Form::open(['url' => '/student/dashboard/projects', 'autocomplete' => 'off']); ?>

          <?php echo Form::label('project_title', 'Your Title *'); ?>

          <?php echo Form::text('project_title', null, ['placeholder' => 'e.g. Project Bazaar']); ?>

          <?php echo Form::label('degree', 'Which pathway best suits this project?'); ?>

          <select name="degree" id="degree">
            <?php foreach($degree as $deg): ?>
              <option value="<?php echo e($deg->id); ?>"><?php echo e($deg->name); ?></option>
            <?php endforeach; ?>
          </select>
          <?php echo Form::label('description', 'Project brief'); ?>

          <?php echo Form::textarea('description', null, ['placeholder' => "Tell us a bit about your project, this doesn't have to be formal... Just explain your idea in your own words."]); ?>


          <?php echo Form::submit('Propose Project', null, ['class' => 'btn']); ?>

         <?php echo Form::close(); ?>

      </div>
    </div>


  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>