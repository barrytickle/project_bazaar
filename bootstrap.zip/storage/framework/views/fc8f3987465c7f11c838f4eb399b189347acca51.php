    <div class="modal-content">
      <h2><?php echo e($project->project_name); ?></h2>
      <p><?php echo e($project->project_description); ?></p>
    </div><!-- content -->
    <div class="modal-footer">
      <span class="author">Proposed by: <?php echo e($project->student->student_id); ?></span>
      <div class="element--like">
        <?php if($like > 0): ?>
        <i class="press" data-slug="<?php echo e($project->project_slug); ?>" data-user="<?php echo e($student->student_id); ?>"></i>
        <?php else: ?>
        <i data-slug="<?php echo e($project->project_slug); ?>" data-user="<?php echo e($student->student_id); ?>"></i>
        <?php endif; ?>
      </div>
    </div>
