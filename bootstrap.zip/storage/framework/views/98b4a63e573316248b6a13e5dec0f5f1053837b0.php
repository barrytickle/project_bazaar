<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <p>Default Role: <span>Staff Member</span></p>

    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">All projects</span></p>
    </div>
    <div class="main-body">
      <div class="block--row">
        <div class="block block--pencil">
          <div class="options">
            <a href="#">View Requests</a>
          </div>
          <span><?php echo count($project); ?></span>
          <p>Proposal Request(s)</p>
        </div>
        <div class="block block--blog">
          <div class="options">
            <a href="#">View Posts</a>
          </div>
          <span><?php echo count($blog); ?></span>
          <p>View Blog Post(s)</p>
        </div>
        <div class="block block--student">
          <div class="options">
            <a href="#">View Approved Projects</a>
          </div>
          <span><?php echo count($student); ?></span>
          <p>Registered Student(s)</p>
        </div>
      </div>
      <div class="table--row">
        <div class="table--block">
          <h2>Projects to propose (<?php echo count($project); ?>)</h2>
          <table class="rwd-table " cellspacing="0">
            <tbody class="table--group">
            <tr class="table--headers">
              <th>Project Name</th>
              <th>Author</th>
              <th>Degree</th>
              <th>Date</th>
              <th>Comments</th>
              <th>View</th>
            </tr>
              <?php foreach($project as $pro): ?>
                  <tr class="table--item <?php echo str_replace(' ', '-', strtolower($pro->degree->name)); ?> <?php echo date('Y',strtotime($pro->project_date)); ?>">
                    <td data-th="Project Name"><?php echo e($pro->project_name); ?></td>
                    <td data-th="Author"><?php echo e($pro->student->student_id); ?></td>
                    <td data-th="Degree"><?php echo e($pro->degree->name); ?></td>
                    <td data-th="Date"><?php echo e($pro->project_date); ?></td>
                    <td data-th="Comments"><?php echo count($pro->comment); ?></td>
                    <td data-th="View"><a class="btn btn-outline" href="/staff/dashboard/projects/<?php echo e($pro->id); ?>/comments" >View Project</button></td>
                  </tr>
              <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <div class="blog--block">
          <h2>Blog Posts</h2>
          <p>The Latest Blog Posts</p>
          <div class="blog--loader">
            <?php foreach($blog as $blogs): ?>
            <div class="blog">
              <h3><?php echo e($blogs->blog_title); ?></h3>
              <p>
                <?php echo substr($blogs->blog_content, 0, 180) . '...'; ?>
              </p>
              <div class="options">
                <a class="btn" href="/staff/dashboard/blog/<?php echo e($blogs->id); ?>/edit">Edit</a>
                <?php echo Form::open(['method' => 'DELETE', 'route' => ['staff.dashboard.blog.destroy', $blogs->id]]); ?>

                 <?php echo Form::submit('Delete', ['class' => 'btn']); ?>

                <?php echo Form::close(); ?>

              </div>
            </div>
          <?php endforeach; ?>

          </div>
        </div>
      </div>



    </div>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.staffdashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>