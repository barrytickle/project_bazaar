<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <p>Edit all blogs</p>

    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">All Blogs</span></p>
    </div>
    <div class="main-body">
      <table class="rwd-table " cellspacing="0">
        <tbody class="table--group">
        <tr class="table--headers">
          <th>Blog Name</th>
          <th>Blog Date</th>
          <th>Blog Type</th>
          <th>Slug</th>
          <th>Preview</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
          <?php foreach($blog as $blogs): ?>
              <tr>
                <td data-th="Blog Name"><?php echo e($blogs->blog_title); ?></td>
                <td data-th="Blog Date"><?php echo date('d-m-y', strtotime($blogs->blog_date)); ?></td>
                <td data-th="Blog Type"><?php echo e($blogs->types->name); ?></td>
                <td data-th="Slug"><?php echo e($blogs->slug); ?></td>
                <td data-th="Preview"><a class="btn btn-outline" href="/staff/dashboard/blog/<?php echo e($blogs->id); ?>">Preview</td>
                <td data-th="Edit"><a class="btn btn-outline" href="/staff/dashboard/blog/<?php echo e($blogs->id); ?>/edit">Edit Blog Post</a></td>
                <td data-th="Delete">
                  <?php echo Form::open(['method' => 'DELETE', 'route' => ['staff.dashboard.blog.destroy', $blogs->id]]); ?>

                   <?php echo Form::submit('Delete', ['class' => 'btn btn-outline']); ?>

                  <?php echo Form::close(); ?>

                </td>
              </tr>
          <?php endforeach; ?>
        </tbody>
    </table>
    </div>


  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.staffdashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>