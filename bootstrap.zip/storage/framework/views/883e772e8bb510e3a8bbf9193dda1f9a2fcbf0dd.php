<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <div class="search--group">
        <span>Searching for:</span>

          <select data-filter-group="degree" id="degree--group">
            <option selected data-filter="*">All Projects</option>
            <?php foreach($degree as $deg): ?>
              <?php if(Auth::user()->student->degree_id == $deg->id): ?>
                <option  data-filter=".<?php echo str_replace(' ', '-', strtolower($deg->name)); ?>" selected><?php echo e($deg->name); ?></option>
              <?php else: ?>
                <option data-filter=".<?php echo str_replace(' ', '-', strtolower($deg->name)); ?>"><?php echo e($deg->name); ?></option>
              <?php endif; ?>
            <?php endforeach; ?>
          </select>
      </div>
      <div class="default-navigation">
        <p><span><?php echo e($degree_count); ?></span> Projects Proposed</p>
        <p><span><?php echo e($staff_count); ?></span> Staff members for pathway</p>
        <div class="select--group" data-filter-group="year"><p>Year</p> <select>
          <?php foreach($years as $year): ?>
            <option data-filter=".<?php echo e($year); ?>"><?php echo e($year); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      </div>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">All projects</span></p>
    </div>
    <div class="main-body">
      <table class="rwd-table " cellspacing="0">
        <tbody class="table--group">
        <tr class="table--headers">
          <th>Project Name</th>
          <th>Author</th>
          <th>Authorized By</th>
          <th>Date</th>
          <th>Likes</th>
          <th>View Project</th>
          <th>Unlike Project</th>
        </tr>
          <?php foreach($project as $pro): ?>
            <?php foreach($pro->like as $like){ ?>
              <?php print_r($like->student_id); ?>
              <?php } ?>
              <?php $show = true; ?>

            <?php if($show){ ?>
              <tr class="table--item <?php echo str_replace(' ', '-', strtolower($pro->degree->name)); ?> <?php echo date('Y',strtotime($pro->project_date)); ?>">
                <td data-th="Project Name"><?php echo e($pro->project_name); ?></td>
                <td data-th="Author"><?php echo e($pro->student->student_id); ?></td>
                <td data-th="Authorized By"><?php echo e($pro->staff[0]->staff_name); ?></td>
                <td data-th="Date"><?php echo e($pro->project_date); ?></td>
                <td data-th="Likes"><?php echo count($pro->like); ?></td>
                <td data-th="View project"><a class="btn btn-outline" href="/student/dashboard/<?php echo e($pro->id); ?>">View Project</a></td>
                <td data-th="Unlike Project"><a class="btn btn-outline btn--like" data-slug="<?php echo e($pro->project_slug); ?>" data-user="<?php echo e(Auth::user()->student->student_id); ?>">Unlike Project</a></td>
              </tr>
            <?php } ?>
          <?php endforeach; ?>
        </tbody>
    </table>
    </div>

  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>