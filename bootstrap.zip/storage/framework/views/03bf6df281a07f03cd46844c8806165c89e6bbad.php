<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>Showing all your recent login attempts</span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">Login History</span></p>
    </div>
    <div class="main-body">
      <table class="rwd-table " cellspacing="0">
        <tbody class="table--group">
        <tr class="table--headers">
          <th>Student ID</th>
          <th>Date</th>
          <th>Time</th>
          <th>IP Address</th>
        </tr>
          <?php foreach($logs as $log): ?>
              <tr class="table--item">
                <td data-th="Student ID"><?php echo e($log->student_id); ?></td>
                <td data-th="Date"><?php echo date('d-m-y', strtotime($log->date));?></td>
                <td data-th="Time"><?php echo date('G:i', strtotime($log->date));?></td>
                <td data-th="IP Address"><?php echo e($log->ip_address); ?></td>
              </tr>
          <?php endforeach; ?>
        </tbody>
    </table>
    </div>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>