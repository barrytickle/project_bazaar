<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <div class="search--group">
        <span>Searching for:</span>

          <select data-filter-group="degree" id="degree--group">
            <option selected data-filter="*">All Projects</option>
            <?php foreach($degree as $deg): ?>
                <option  data-filter=".<?php echo str_replace(' ', '-', strtolower($deg->name)); ?>"><?php echo e($deg->name); ?></option>
            <?php endforeach; ?>
          </select>
      </div>
      <div class="default-navigation">
        <p><span><?php echo e($degree_count); ?></span> Projects Proposed</p>
        <p><span><?php echo e($staff_count); ?></span> Staff members for pathway</p>
        <div class="select--group" data-filter-group="year"><p>Year</p> <select>
          <?php foreach($years as $year): ?>
            <option data-filter=".<?php echo e($year); ?>"><?php echo e($year); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      </div>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">All projects</span></p>
    </div>
    <div class="main-body">
      <table class="rwd-table " cellspacing="0">
        <tbody class="table--group">
        <tr class="table--headers">
          <th>Project Name</th>
          <th>Degree</th>
          <th>Author</th>
          <th>Authorized By</th>
          <th>Date</th>
          <th>Comments</th>
          <th>Approve</th>
        </tr>
          <?php foreach($project as $pro): ?>
              <tr class="table--item <?php echo str_replace(' ', '-', strtolower($pro->degree->name)); ?> <?php echo date('Y',strtotime($pro->project_date)); ?>">
                <td data-th="Project Name"><?php echo e($pro->project_name); ?></td>
                <td data-th="Degree"><?php echo e($pro->degree->name); ?></td>
                <td data-th="Author"><?php echo e($pro->student->student_id); ?></td>
                <td data-th="Authorized By">
                  <?php if($pro->is_authorized): ?>
                      <?php echo e($pro->staff[0]->staff_name); ?>

                  <?php else: ?>
                      Not Authorized
                  <?php endif; ?>
                </td>
                <td data-th="Date"><?php echo e($pro->project_date); ?></td>
                <td data-th="Comments"><a class="btn btn-outline" href="/staff/dashboard/projects/<?php echo e($pro->id); ?>/comments">View Comments <?php echo count($pro->comment); ?></a></td>
                <td data-th="Approve">
                  <?php if($pro->is_authorized): ?>
                    <?php if($pro->staff[0]->staff_name == Auth::user()->staff->staff_name): ?>
                      <a class="btn btn-outline btn-approve" href="/staff/dashboard/projects/<?php echo e($pro->id); ?>/approve" >Unapprove Project</a>
                    <?php else: ?>
                      <?php echo e($pro->staff[0]->staff_name); ?> must unapprove
                    <?php endif; ?>

                  <?php else: ?>
                    <a class="btn btn-outline btn-approve" href="/staff/dashboard/projects/<?php echo e($pro->id); ?>/approve">Approve Project</a>
                  <?php endif; ?>
                </td>
              </tr>
          <?php endforeach; ?>
        </tbody>
    </table>
    </div>


  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.staffdashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>