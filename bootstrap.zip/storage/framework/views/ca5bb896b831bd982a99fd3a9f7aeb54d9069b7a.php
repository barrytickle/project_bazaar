<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <p>Edit all Degree Types</p>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">All Degrees</span></p>
    </div>
    <div class="main-body">
      <table class="rwd-table " cellspacing="0">
        <tbody class="table--group">
        <tr class="table--headers">
          <th>Degree name</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
          <?php foreach($degrees as $degree): ?>
              <tr>
                <td data-th="Degree Name"><?php echo e($degree->name); ?></td>
                <td data-th="Edit"><a class="btn btn-outline" href="/staff/dashboard/degrees/<?php echo e($degree->id); ?>/edit">Edit Degree Pathway</a></td>
                <td data-th="Delete">
                  <?php echo Form::open(['method' => 'DELETE', 'route' => ['staff.dashboard.degrees.destroy', $degree->id]]); ?>

                   <?php echo Form::submit('Delete', ['class' => 'btn btn-outline']); ?>

                  <?php echo Form::close(); ?>

                </td>
              </tr>
          <?php endforeach; ?>
        </tbody>
    </table>
    </div>


  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.staffdashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>