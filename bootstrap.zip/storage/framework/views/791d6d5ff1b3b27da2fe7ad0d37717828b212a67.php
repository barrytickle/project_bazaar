<?php $__env->startSection('title', $sample->blog_title); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>Showing Sample: <?php echo e($sample->blog_title); ?></span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display"><a href="/student/dashboard">Home</a> > <a href="/student/dashboard/sample-projects">Sample Projects</a> > <?php echo e($sample->blog_title); ?></span></p>
    </div>
    <div class="main-body">
      <div class="text--group">
        <h1><?php echo e($sample->blog_title); ?></h1>
        <p><?php echo e($sample->blog_content); ?></p>
      </div>
    </div>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>