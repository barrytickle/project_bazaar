<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>Edit <?php echo e($blog->blog_title); ?></span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">Edit your blog post</span></p>
    </div>
    <div class="main-body">
      <div class="text--group">
        <h1>Edit: <?php echo e($blog->blog_title); ?></h1>
        <h2>Blog Details</h2>
        <?php echo Form::model($blog, ['method' => 'PATCH', 'url' => 'staff/dashboard/blog/'. $blog->id]); ?>

          <?php echo Form::label('blog_title', 'Your Title *'); ?>

          <?php echo Form::text('blog_title', $blog->blog_title); ?>

          <?php echo Form::label('blog_slug', 'Alter Slug'); ?>

          <?php echo Form::text('blog_slug', $blog->slug); ?>

          <?php echo Form::label('type', 'Which pathway best suits this project?'); ?>

          <select name="type" id="type">
            <?php foreach($type as $types): ?>
              <?php if($types->id == $blog->type): ?>
                <option value="<?php echo e($types->id); ?>" selected><?php echo e($types->name); ?></option>
              <?php else: ?>
                <option value="<?php echo e($types->id); ?>"><?php echo e($types->name); ?></option>
              <?php endif; ?>
            <?php endforeach; ?>
          </select>
          <?php echo Form::label('description', 'Project brief'); ?>

          <?php echo Form::textarea('description', $blog->blog_content); ?>


          <?php echo Form::submit('Update blog', null, ['class' => 'btn']); ?>

         <?php echo Form::close(); ?>

      </div>
    </div>



  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.staffdashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>