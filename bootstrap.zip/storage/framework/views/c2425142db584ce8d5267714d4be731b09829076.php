<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>You are previewing all blog posts, all posts have been wrote by the tutors which are available to the system.</span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">Learn what a project is</span></p>
    </div>
    <div class="main-body">
      <div class="dashboard--right">
        <span>Total Articles: <?php echo e($count); ?> </span>
      </div>
      <div class="text--group">
        <h1>The fundamentals of a project</h1>
        <p>The following blog posts will allow you to learn about a project, providing you with the essential guidelines you need to excel your dissertation.</p>
        <div class="blog--list">
          <?php foreach($blog as $blogs): ?>
            <div class="blog">
              <h2><?php echo e($blogs->blog_title); ?></h2>
              <p>
                <?php echo substr($blogs->blog_content, 0, 180) . '...'; ?>
              </p>
                <a href="/student/dashboard/blog/<?php echo e($blogs->slug); ?>"><span>Continue reading</span> <img src="/images/icons/arrow-right-circle.svg"></a>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>