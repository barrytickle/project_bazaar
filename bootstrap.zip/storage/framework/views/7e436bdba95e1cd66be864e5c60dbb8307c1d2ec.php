<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>Showing Project: <?php echo e($project->project_name); ?></span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display"><?php echo e($project->project_name); ?></span></p>
    </div>
    <div class="main-body">
      <div class="dashboard--right">
        <div class="element--like">
          <?php if($like > 0): ?>
          <i class="press" data-slug="<?php echo e($project->project_slug); ?>" data-user="<?php echo e(Auth::user()->student->student_id); ?>"></i>
          <?php else: ?>
          <i data-slug="<?php echo e($project->project_slug); ?>" data-user="<?php echo e(Auth::user()->student->student_id); ?>"></i>
          <?php endif; ?>
        </div>
      </div>
      <div class="text--group">
        <h1><?php echo e($project->project_name); ?></h1>
        <h3>Developed by: <?php echo e($project->student->student_id); ?></h3>

        <p><?php echo e($project->project_description); ?></p>
      </div>
    </div>



  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>