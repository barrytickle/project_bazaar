<?php $__env->startSection('title', 'Test'); ?>
<?php $__env->startSection('content'); ?>
  
  <?php $__env->startSection('dashboardcontent'); ?>
    <div class="toolbar toolbar--top filters">
      <span>Edit <?php echo e($degree->name); ?></span>
    </div>
    <div class="toolbar toolbar--secondary">
      <p>You are currently viewing: <span class="project--display">Edit Degree Pathway</span></p>
    </div>
    <div class="main-body">
      <div class="text--group">
        <h1>Edit: <?php echo e($degree->name); ?></h1>
        <h2>Degree Details</h2>
        <?php echo Form::model($degree, ['method' => 'PATCH', 'url' => 'staff/dashboard/degrees/'. $degree->id]); ?>

          <?php echo Form::label('name', 'Your Title *'); ?>

          <?php echo Form::text('name', $degree->name); ?>

          <?php echo Form::submit('Propose Project', null, ['class' => 'btn']); ?>

         <?php echo Form::close(); ?>

      </div>
    </div>



  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.staffdashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>