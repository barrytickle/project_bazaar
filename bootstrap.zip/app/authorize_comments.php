<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class authorize_comments extends Model
{
    //
}
