<footer>
  <nav>
    <a href="/login">Student Login</a>
    <a href="/privacy">Privacy</a>
    <a href="/terms-and-conditions">Terms &amp; Conditions</a>
    <a href="/resources">Resources</a>
  </nav>
</footer>
